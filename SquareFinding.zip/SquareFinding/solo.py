import os



def zerolistmaker(n):
    """Utility fonction"""
    listofzeros = [0] * n
    return listofzeros

def getVoidShape(x,y):
    """create an void image"""
    shape = []
    for x in range(0,x):
        shape.append(zerolistmaker(y))
    return shape

def printShape(shape):
    """print shape, the default print() return the list so, for debug, show a shape an human can understand"""
    x = len(shape)
    y = len(shape[0])
    proceed_shape = getVoidShape(y,x)
    for i in range(x):
        for j in range(y):
            if str(shape[i][j]) == '0':
                proceed_shape[j][i] = "'"
            else:
                
                proceed_shape[j][i] = str(shape[i][j])
    for j in range(y):
        L = "".join(proceed_shape[j])
        #if L != '                                        ':
        print(L)
    print('')

def ExtractCaptchaFromFile(captchaPath):
        
    """
    extract captcha from file
    """
    
    y = 0
    x = 0
    image = []
    decalage_x = 0
    decalage_x_fin = 0
    end_decalage = False
    y_ligne = []
    file = open(captchaPath,'r')
    for ligne in file:
        y_ligne = []
        x = 0
        s = 0
        for char in ligne:
            if char != '\n' and char != ' ':
                s += int(char)
                x += 1
                y_ligne.append(int(char))
        if s <15 and image.__len__() <= 240:
            image.append(y_ligne)
            end_decalage = True
        elif not end_decalage:
            decalage_x += 1
        else:
            decalage_x_fin += 1
                
    
        y += 1
    y = len(image)
    x_len = x
    y_len = y
    proceed_image = getVoidShape(x,y)
    for j in range(y):
        for i in range(x):
            proceed_image[i][j] = image[j][i]
    #printShape(proceed_image)
    #print(decalage_x)
    return proceed_image, decalage_x, x_len, y_len
    
if __name__ == "__main__":
    image,deca, x,y = ExtractCaptchaFromFile("captcha/6.txt")
    printShape(image)
    print(deca)
